@extends('frontEnd.master')

@section('title')
Shipping
@endsection

@section('mainContent')
<hr/>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="well lead text-center text-success"> 
                <h1>Thanks for you order. We will process it soon....</h1>
            </div>
        </div>
    </div>
</div>

@endsection