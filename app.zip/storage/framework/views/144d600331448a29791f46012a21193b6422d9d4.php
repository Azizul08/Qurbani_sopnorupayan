
<?php $__env->startSection('content'); ?>

<hr/>
<h3 class="text-center text-success"><?php echo e(Session::get('message')); ?></h3>
<hr/>
<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>ID</th>
            <th>Manufacturer Name</th>
            <th>Manufacturer Description</th>
            <th>Publication Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr> 
            <th scope="row"><?php echo e($manufacturer->id); ?></th>
            <td><?php echo e($manufacturer->manufacturerName); ?></td>
            <td><?php echo e($manufacturer->manufacturerDescription); ?></td>
            <td><?php echo e($manufacturer->publicationStatus == 1 ? 'Published'  : 'Unpublished'); ?></td>
            <td>
                <a href="<?php echo e(url('/manufacturer/edit/'.$manufacturer->id)); ?>" class="btn btn-success">
                    <span class="glyphicon glyphicon-edit"></span>
                </a>
                <a href="<?php echo e(url('/manufacturer/delete/'.$manufacturer->id)); ?>" class="btn btn-danger" onclick="return confirm('Are You Sure To Delete This');">
                    <span class="glyphicon glyphicon-trash"></span>
                </a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>