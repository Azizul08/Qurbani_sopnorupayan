

<?php $__env->startSection('title'); ?>
Shipping
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mainContent'); ?>
<hr/>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="well lead text-center text-success">Hello <b><?php echo e($customerById->lastName); ?></b>. You have to give us product shipping information to complete your valuable order. If your product billing information & shipping information are same then just press on save shipping info button</div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
    <div class="col-lg-12">
        <h3 class="text-center">Shipping Form </h3>
        <hr/>
        <div class="well box box-primary">
            <?php echo Form::open(['url'=>'/checkout/save-shipping', 'method'=>'POST', 'name'=>'shippingForm']); ?>

            <div class="box-body">
                <div class="form-group">
                    <label for="exampleInputEmail1">Full Name</label>
                    <input type="text" name="fullName" value="<?php echo e($customerById->firstName.' '.$customerById->lastName); ?>" class="form-control" placeholder="First Name">
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email Address</label>
                    <input type="email" value="<?php echo e($customerById->emailAddress); ?>" name="emailAddress" class="form-control" placeholder="Email Address">
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Address</label>
                    <textarea name="address" class="form-control" placeholder="Enter Address"><?php echo e($customerById->address); ?></textarea>
                </div>
                 <div class="form-group">
                    <label for="exampleInputEmail1">Phone Number</label>
                    <input type="number" name="phoneNumber" value="<?php echo e($customerById->phoneNumber); ?>" class="form-control" placeholder="Enter Phone Number">
                </div>
                <div class="form-group">
                    <label>Dist. Name</label>
                    <select class="form-control" name="districtName">
                        <option>---Select District Name---</option>
                        <option value="Dhaka">Dhaka</option>
                        <option value="nar">Narayanganj</option>
                        <option value="Savar">Savar</option>
                        <option value="Barisal">Barisal</option>
                        <option value="Gazipur">Gazipur</option>
                        <option value="Comilla">Comilla</option>
                    </select>
                </div>
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
                <button type="submit" class="btn btn-primary btn-block">Save Shipping Info</button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
    <script>
        document.forms['shippingForm'].elements['districtName'].value ='<?php echo e($customerById->districtName); ?>';
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>