<?php $__env->startSection('content'); ?>
<hr/>
<h3 class="text-center text-success"><?php echo e(Session::get('message')); ?></h3>
<hr/>
<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>Product Name</th>
            <th>Category Name</th>
            <th>Manufacturer Name</th>
            <th>Product Price</th>
            <th>Product Quantity</th>
            <th>Publication Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr> 
            <th scope="row"><?php echo e($product->productName); ?></th>
            <td><?php echo e($product->categoryName); ?></td>
            <td><?php echo e($product->manufacturerName); ?></td>
            <td>TK. <?php echo e($product->productPrice); ?></td>
            <td> <?php echo e($product->productQuantity); ?></td>
            <td><?php echo e($product->publicationStatus == 1 ? 'Published' : 'Unpublished'); ?></td> 
            <td>
                <a href="<?php echo e(url('/product/view/'.$product->id)); ?>" class="btn btn-info" title="Product View">
                    <span class="glyphicon glyphicon-info-sign"></span>
                </a>
                <a href="<?php echo e(url('/product/edit/'.$product->id)); ?>" class="btn btn-success" title="Product Edit">
                    <span class="glyphicon glyphicon-edit"></span>
                </a>
                <a href="<?php echo e(url('/product/delete/'.$product->id)); ?>" title="Product Delete" class="btn btn-danger" onclick="return confirm('Are you sure to delete this'); ">
                    <span class="glyphicon glyphicon-trash"></span>
                </a>
            </td> 
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>