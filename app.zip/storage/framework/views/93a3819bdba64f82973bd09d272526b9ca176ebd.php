<?php $__env->startSection('title'); ?>
Shipping
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mainContent'); ?>
<hr/>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="well lead text-center text-success"> 
                <h1>Thanks for you order. We will process it soon....</h1>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>