

<?php $__env->startSection('title'); ?>
Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mainContent'); ?>
<div class="checkout">
    <div class="container">
        <h3>My Shopping Bag</h3>
        <div class="table-responsive checkout-right animated wow slideInUp" data-wow-delay=".5s">
            <table class="timetable_sub">
                <thead>
                    <tr>
                        <th>Remove</th>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Item Total</th>
                    </tr>
                </thead>
                <?php $total = 0 ?>
                <?php $__currentLoopData = $cartProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="rem1">
                    <td class="invert-closeb">
                        <div class="rem">
                            <a href="<?php echo e(url('/cart/delete/'.$cartProduct->rowId)); ?>" class="btn btn-danger">
                                <span class="glyphicon glyphicon-trash"></span>
                            </a>
                        </div>
                    </td>
                    <td class="invert"><?php echo e($cartProduct->name); ?></td>
                    <td class="invert">
                        <!-- <div class="quantity">                           
                            <form>
                                <div class="input-group">
                                    <input type="number" name="qty" class="form-control" value="<?php echo e($cartProduct->qty); ?>"/>
                                    <span class="input-group-btn">
                                        <button type="submit" name="btn" class="btn btn-primary">
                                            <span class="glyphicon glyphicon-upload"></span>
                                        </button>
                                    </span>
                                </div>
                            </form>
                        </div> -->
                        <?php echo e($cartProduct->qty); ?>

                    </td>

                    <td class="invert">TK. <?php echo e($cartProduct->price); ?></td>
                    <td class="invert">TK. <?php echo e($itemTotal = $cartProduct->price*$cartProduct->qty); ?></td>
                </tr>
                <?php $total = $total + $itemTotal ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!--quantity-->
            </table>
        </div>
        <div class="checkout-left">	
            <div class="checkout-right-basket animated wow slideInRight" data-wow-delay=".5s">
                <a href="<?php echo e(url('/')); ?>"><span class="glyphicon glyphicon-menu-left" aria-hidden="true"></span>Back To Shopping</a>                
                <?php
                // $customerId = Session::get('customerId');

                // $shippingId = Session::get('shippingId');
                // if ($customerId != null && $shippingId != null) {
                // dd($cartProduct->name);
                 // $productname=Session::get($cartProducts->name);

                if ($total != 0) { ?>
                    <a href="<?php echo e(url('/checkout/shipping')); ?>"><span class="glyphicon glyphicon-menu-left" aria-hidden="true"></span>Checkout</a>                
                <?php } else { ?>
                    <a href="<?php echo e(url('/')); ?>"><span class="glyphicon glyphicon-menu-left" aria-hidden="true"></span>Checkout</a>                
                <?php } ?>
            </div>
            <div class="checkout-left-basket animated wow slideInLeft" data-wow-delay=".5s">
                <h4>Shopping basket</h4>
                <ul>
                    <li>Total <i>-</i> <span>TK. <?php echo e($total); ?></span></li>
                    <?php
                    Session::put('orderTotal', $total);
                    ?>
                </ul>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>