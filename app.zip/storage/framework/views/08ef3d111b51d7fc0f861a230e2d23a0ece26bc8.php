
<?php $__env->startSection('content'); ?>

<hr/>
<h3 class="text-center text-success"><?php echo e(Session::get('message')); ?></h3>
<hr/>
<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>ID</th>
            <th>Category Name</th>
            <th>Category Description</th>
            <th>Publication Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr> 
            <th scope="row"><?php echo e($category->id); ?></th>
            <td><?php echo e($category->categoryName); ?></td>
            <td><?php echo e($category->categoryDescription); ?></td>
            <td><?php echo e($category->publicationStatus == 1 ? 'Published' : 'Unpublished'); ?></td> 
            <td>
                <a href="<?php echo e(url('/category/edit/'.$category->id)); ?>" class="btn btn-success">
                    <span class="glyphicon glyphicon-edit"></span>
                </a>
                <a href="<?php echo e(url('/category/delete/'.$category->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete this'); ">
                    <span class="glyphicon glyphicon-trash"></span>
                </a>
            </td> 
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<!--<ul>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($category->categoryName); ?></li>
    <li><?php echo e($category->categoryDescription); ?></li>
    <li><?php echo e($category->publicationStatus); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>