<style type="text/css">

    /*@import  url('https://fonts.googleapis.com/css?family=Lato');*/

    body { -webkit-text-size-adjust: none; -ms-text-size-adjust: none; margin: 0; padding: 0; background: #f1f1f1;}


</style>
<div style="Margin:0;">
    <center>
        <div class="m_7178298702458433966webkit">
            <table align="center" cellpadding="0" cellspacing="0" border="0" style="width:98%;Margin:0 auto;background-color:#ffffff">
                <tbody><tr>
                    <td style="font-size:0"></td>
                    <td align="center" valign="top" style="width:600px">
                        <table align="center" cellpadding="0" cellspacing="0" border="0" style="width:100%;max-width:600px;border: 1px solid #d3d3d3;">
                            
                            <tbody>
                            <tr>
                                <td style="background-color:#efefef;">
                                    <table cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;Margin:auto;table-layout:fixed" align="center">
                                        <tbody><tr>
                                            <td valign="top">
                                                <table align="center" cellpadding="0" cellspacing="0" border="0" style="height:100%;width:100%">
                                                    <tbody>
                                                    <tr>
                                                        <td valign="top" align="left" style="padding:10px 20px">
                                                            <a style="text-decoration:none" href="#" target="_blank">
                                                                <img mc:hideable="" mc:edit="" src="http://qurbani.sopnorupayan.com/public/frontEnd/images/logo.png" height="58" alt="" style="height:58px;">
                                                            </a>
                                                        </td>
                                                        
                                                    </tr>


                                                </tbody></table>
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <table cellpadding="0" cellspacing="0" style="width:calc(100% - 40px);margin:auto;text-align:left;padding:30px 20px 0px" dir="ltr">
                                        <tbody>
                                            <tr>
                                                <td height="28" align="center" valign="top" style="font-size:28px;line-height:28px;">&nbsp;</td>
                                            </tr>
                                            

                                        <tr>
                                            <td mc:hideable="" mc:edit="" class="heroSubTitle" align="center" valign="middle" style="font-family: 'Lato', sans-serif;color: #37393d;font-size: 14px;font-weight: 600;letter-spacing: 0px;padding: 0;padding-bottom: 7px;text-align: left;">
                                                Dear <?php echo e($firstname); ?> <?php echo e($lastname); ?> ,
                                            </td>
                                        </tr>

                                        <tr>
                                                <td mc:hideable="" mc:edit="" class="heroSubTitle" align="center" valign="middle" style="font-family:'Lato', sans-serif;color:#37393d;font-size:12px;line-height:20px;font-weight:400;letter-spacing:0px;padding:0;padding-bottom:15px; text-align: left;">
                                                    Just to let you know — we've received your order # <?php echo e($orderId); ?> , and it is now being processed:.
                                                </td>
                                            </tr>
                                            <tr>
                                                <td height="28" align="center" valign="top" style="font-size:28px;line-height:28px;">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td class="heroSubTitle" align="center" valign="middle" style="font-family:'Lato', sans-serif;color:#37393d;font-size:12px;line-height:20px;font-weight:600;letter-spacing:0px;padding:0;padding-bottom:15px; text-align: left;">Pay with cash upon delivery.</td>
                                            </tr>
                                            
	                                     
                                  <tr>
                                                <td class="heroSubTitle" align="center" valign="middle" style="font-family:'Lato', sans-serif;color:#96588a;font-size:12px;line-height:20px;font-weight:600;letter-spacing:0px;padding:0;padding-bottom:15px; text-align: left;">Order Id:  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <?php echo e($orderId); ?>  </td>
                                            </tr>
                                            
                                             <tr>
                                                <td class="heroSubTitle" align="center" valign="middle" style="font-family:'Lato', sans-serif;color:#96588a;font-size:12px;line-height:20px;font-weight:600;letter-spacing:0px;padding:0;padding-bottom:15px; text-align: left;">ProductName:  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <?php echo e($productName); ?>  </td>
                                            </tr> 
                                        <tr>
                                        <td class="heroSubTitle" align="center" valign="middle" style="font-family:'Lato', sans-serif;color:#96588a;font-size:12px;line-height:20px;font-weight:600;letter-spacing:0px;padding:0;padding-bottom:15px; text-align: left;">ProductPrice:&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<?php echo e($productPrice); ?> </td>
                                            </tr> 
                                            <!-- <tr>
                                                <td class="heroSubTitle" align="center" valign="middle" style="font-family:'Lato', sans-serif;color:#37393d;font-size:12px;line-height:20px;font-weight:600;letter-spacing:0px;padding:0;padding-bottom:15px; text-align: left;">Investor Password: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  </td>
                                            </tr> -->
                                            <!-- <tr>
                                                <td class="heroSubTitle" align="center" valign="middle" style="font-family:'Lato', sans-serif;color:#37393d;font-size:12px;line-height:20px;font-weight:600;letter-spacing:0px;padding:0;padding-bottom:15px; text-align: left;">Server:&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp;     </td>
                                            </tr> -->
                                            

                                        <tr>
                                                <td align="left" valign="top">
                                                    <table border="0" align="left" cellpadding="0" cellspacing="0" style="background-color: #efefef; border-radius: 4px; width: 100%;">
                                                        <tbody>
                                                            <tr>
                                                                <td mc:hideable="" mc:edit="" class="sectionDesc" align="left" valign="middle" style="font-family:'Open Sans',Arial,Helvetica,sans-serif;color:#2ED57F;font-size:14px;line-height:22px;font-weight:600;letter-spacing:0px;background: #efefef;padding: 10px 20px;">
                                                                    
                                                                Billing address 
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    
                                                </td>
                                            </tr>

                                            <!-- <tr>
                                                <td mc:hideable="" mc:edit="" class="heroSubTitle" align="center" valign="middle" style="font-family:'Lato', sans-serif;color:#37393d;font-size:12px;line-height:20px;font-weight:400;letter-spacing:0px;padding:0;padding-bottom:15px; text-align: left;padding-top:15px;">
                                                    You can download the MetaTrader trading account from inside your secure client area by clicking on the link below: <a href="">Download Trading Platform </a>
                                                </td>
                                            </tr> -->
                                            
                                             <tr>
                                            <td height="20" align="center" valign="top" style="font-size:20px;line-height:20px;">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td class="heroSubTitle" align="center" valign="middle" style="font-family:'Lato', sans-serif;color:#37393d;font-size:12px;line-height:10px;font-weight:400;letter-spacing:0px;padding:0;padding-bottom:15px; text-align: left;">
                                                   <span style="font-weight: bold;"> </span>Name : <?php echo e($firstname); ?> <?php echo e($lastname); ?>

                                                </td>
                                            </tr>

                                            <tr>
                                    <td class="heroSubTitle" align="center" valign="middle" style="font-family:'Lato', sans-serif;color:#37393d;font-size:12px;line-height:10px;font-weight:400;letter-spacing:0px;padding:0;padding-bottom:15px; text-align: left;">
                                       <span style="font-weight: bold;"> </span>  Address : <?php echo e($address); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td class="heroSubTitle" align="center" valign="middle" style="font-family:'Lato', sans-serif;color:#37393d;font-size:12px;line-height:10px;font-weight:400;letter-spacing:0px;padding:0;padding-bottom:15px; text-align: left;">
                                       <span style="font-weight: bold;"> </span>  Phone : <?php echo e($phone); ?>

                                    </td>
                                </tr>
                                
                                 <tr>
                                        <td height="20" align="center" valign="top" style="font-size:20px;line-height:20px;">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td mc:hideable="" mc:edit="" class="sectionDesc" align="left" valign="middle" style="font-family:'Open Sans',Arial,Helvetica,sans-serif;color:#2ED57F;font-size:14px;line-height:22px;font-weight:600;letter-spacing:0px;background: #efefef;padding: 10px 20px;">
                                        Help and Support
                                    </td>
                                </tr>

                                       

                                       
                                        <tr>
                                            <td height="20" align="center" valign="top" style="font-size:30px;line-height:30px;">&nbsp;</td>
                                        </tr>

                                        

                                        


                                        <tr>
                                            <td mc:hideable="" mc:edit="" class="sectionDesc" align="left" valign="middle" style="font-family:'Open Sans',Arial,Helvetica,sans-serif;color:#039ecd;font-size:14px;line-height:22px;font-weight:400;font-style: italic; letter-spacing:0px;background: #ffffff;">
                                                Contact Info :
                                            </td>
                                        </tr>

                                        <tr>
                                            <td height="10" align="center" valign="top" style="font-size:10px;line-height:10px;">&nbsp;</td>
                                        </tr>

                                        <tr>
                                            <td align="center" valign="top">
                                                <table border="0" align="center" cellpadding="0" cellspacing="0" style="width: 100%;">
                                                    <tbody>
                                                    <tr>
                                                        <td mc:hideable="" mc:edit="" align="left" valign="middle" style="vertical-align: top; width: 50%">
                                                            <table border="0" align="center" cellpadding="0" cellspacing="0" style="width: 94%;">
                                                                <tbody>
                                                                <tr style="font-family: 'Lato', sans-serif;font-size: 12px;font-weight: 300;line-height: 20px;letter-spacing: 0px;color: #37393d;list-style: none;">
                                                                    <td>Mirpur 6, Dhaka , Bangladesh</td>
                                                                    <td></td>
                                                                </tr>
                                                                
                                                                </tbody>
                                                            </table>
                                                        </td>

                                                        <td mc:hideable="" mc:edit="" align="left" valign="middle" style="vertical-align: top;width: 50%">
                                                            <table border="0" align="center" cellpadding="0" cellspacing="0" style="width: 94%;">
                                                                <tbody>
                                                                
                                                                <tr style="font-family: 'Lato', sans-serif;font-size: 12px;font-weight: 300;line-height: 20px;letter-spacing: 0px;color: #37393d;list-style: none;">
                                                                    <td>Phone  :</td>
                                                            <td>01751383947</td>
                                                                </tr>
                                                                <tr style="font-family: 'Lato', sans-serif;font-size: 12px;font-weight: 300;line-height: 20px;letter-spacing: 0px;color: #37393d;list-style: none;">
                                                                    <td>Email  :</td>
                                                                    <td>ruhulamin.ce.11@gmail.com </td>
                                                                </tr>
                                                                <tr style="font-family: 'Lato', sans-serif;font-size: 12px;font-weight: 300;line-height: 20px;letter-spacing: 0px;color: #37393d;list-style: none;">
                                                                    <td>Website:</td>
                                                                    <td>sopnorupayan.com </td>
                                                                </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>

                                                    </tr>
                                                    </tbody></table>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td height="10" align="center" valign="top" style="font-size:10px;line-height:10px;">&nbsp;</td>
                                        </tr>


                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            

                        </tbody></table>
                    </td>
                    <td style="font-size:0"></td>
                </tr>
            </tbody></table>
        </div>
    </center>

</div></div>